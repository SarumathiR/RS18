<?php 
	include('functions.php');

	if (!isLoggedIn()) {
		$_SESSION['msg'] = "You must log in first";
		header('location: login.php');
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<meta charset="utf-8">
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- STYLE CSS -->	
		<link rel="stylesheet" href="css1/style.css">
		<link rel="stylesheet" href="style2.css">
</head>
<body bgcolor="lightpink">
	<div class="wrapper">
			<div class="inner">
				<div class="image-holder">
					<img src="images1/registration-form-4.jpg" alt="">
				</div>
				<form accept="">
	<div>
		<!-- notification message -->
		<?php if (isset($_SESSION['success'])) : ?>
			<div class="error success" >
				<h3>
					<?php 
						echo $_SESSION['success']; 
						unset($_SESSION['success']);
					?>
				</h3>
			</div>
		<?php endif ?>
		<!-- logged in user information -->
		<div class="profile_info">
			<img src="aimages/user_profile.png"  >

			<div>
				<?php  if (isset($_SESSION['user'])) : ?>
					<strong><?php echo $_SESSION['user']['username']; ?></strong>

					<small>
						<i  style="color: #888;">(<?php echo ucfirst($_SESSION['user']['user_type']); ?>)</i> 
						<br>
						   <div class="form-holder">                           
			<button  class="btn" ><font color="white"><a href="submenu.html">Menu</a></font></button>
			
		</div>
		<br>
						   <div class="form-holder">                           
			<button  class="btn" ><a href="appoin.php">Appoinment</a></button>
			
		</div><br>
		      <div class="form-holder">
					<button class="btn"><a href="review.php">Review's</a></button>
				</div><br>
						 <div class="form-holder">
					<button type="submit" class="btn"><a href="index.php?logout='1'">logout</a></button>
				</div><br>
				



					</small>

				<?php endif ?>
			</div>
		</div>
	</div>


             
	</form>
</body>
</html>