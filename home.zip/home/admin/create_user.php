<?php include('../functions.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration system PHP and MySQL - Create user</title>
	

		<meta charset="utf-8">
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- STYLE CSS -->	
		<link rel="stylesheet" href="css/style.css">
	
</head>
<body>
	<div class="wrapper">
			<div class="inner">
				<div class="image-holder">
					<img src="images/registration-form-4.jpg" alt="">
				</div>

	
	<form method="post" action="create_user.php">

		<?php echo display_error(); ?>

		<h3>Sign Up</h3>
					<div class="form-holder active">
						<input type="text" placeholder="name" class="form-control" name="username" value="<?php echo $username; ?>">
					</div>
					<div class="form-holder">
						<input type="text" placeholder="e-mail" class="form-control" name="email" value="<?php echo $username; ?>">
					</div>
					<div class="form-holder">
			<input type="text" placeholder="user_type" class="form-control" id="user_type" name="user_type" >
			
		</div>
					<div class="form-holder">
						<input type="password" placeholder="Password" class="form-control"  name="password_1"style="font-size: 15px; >
					</div>
					<div class="form-holder">
						<input type="password" placeholder="Conform_Password" class="form-control" name="password_2" style="font-size: 15px; >
					</div>
					<div class="checkbox">
						<label>
							<input type="checkbox" checked> I agree all statement in <a href="#">Terms & Conditions</a>
							<span class="checkmark"></span>
						</label>
					</div>
					<div class="form-holder">
			<button type="submit" class="btn" name="register_btn"> + Create user</button>
		</div>
					
				</form>
			</div>
		</div>

		<script src="js/jquery-3.3.1.min.js"></script>
		<script src="js/main.js"></script>

	
		
	</form>
</body>
</html>