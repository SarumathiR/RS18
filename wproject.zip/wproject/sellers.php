<html>
<head>
<title> seller</title>
<style>
#content{
      width: 100%;
      marigin: 20px auto;
       border-radius:50px;
       border-style:solid;
       border-width:3px
       border-color:red;
       background-color:white;
      border-width:3px;
        margin-left: 200px;
       margin-right: 210px;
      padding: 40px;
      margin-bottom: 20px; 
      height: 100px;
      width: 650px;" 
      
}
form{
    width:100%;
      marigin: 40px auto;
}
form div{
 margin-left:170px;
}
body{ 
background-image: url("bg3.jpg"); 
background-repeat:no-repeat; 
background-size: 100%; 
} 
p{ 
color:crimson;
font-size: 60px; 
font-weight: 20px; 

} 
.btn { 
background-color:lawngreen; 
border: none; 
color: white; 
padding: 12px 30px; 
cursor: pointer; 
font-size:15px;
float: right;
margin-right:230px;
text-decoration: none; 
transform: translate(-80px,0px);
border-radius: 15px; 
} 
.btn:hover { 
background-color: darkmagenta; 
} 
</style>
</head>
<body>
<p >Arts Details with Contact Information</p> <br> <br>
<div id="content">
<form action="" method="post" enctype="multipart/form-data">
<input type="file" name="image"/><br>
<textarea name="text" cols="50" rows="4" placeholder="enter the contact information"></textarea><br>
</div>
<input type="submit" class="btn" name="submit"/>
</form>
<?php
$db=mysqli_connect("localhost","root","","artsy");

if(isset($_POST['submit'])){
$Text = $_POST['text'];
$filename=addslashes($_FILES["image"]["name"]);
$tmpname=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
$filetype=addslashes($_FILES["image"]["type"]);
$array=array('jpg','jpeg');
$ext=pathinfo($filename,PATHINFO_EXTENSION);
if(!empty($filename)){
if(in_array($ext,$array)){
$sql="INSERT into seller(name,Image,Text)values('$filename','$tmpname','$Text')";
mysqli_query($db, $sql);
 header('location:2.html');
}
else{
echo "unsported formate";
}
}
else{
echo "please select an image";
}
}

?>

</body>
</html>