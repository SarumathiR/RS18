<?php
$con=mysqli_connect("localhost","root","","artsy");
if($con)
	echo "database connected";


?>